# Brain Trust Hub — how to finish the site

This site is pure HTML and CSS — no JavaScript, no build tools. The styling
is now embedded directly inside every HTML file (in a `<style>` block), so
each page is fully self-contained — you can open any single `.html` file on
its own, from anywhere, and it will always be styled correctly. (The
standalone `style.css` file is included too, just for reference — the pages
no longer depend on it.)

Every video on the site is a YouTube embed, so you just need each video's
YouTube link.


## 1. Add your YouTube videos
Every video on the site is currently a placeholder `<iframe>` pointing at a
fake video ID. To make a video play, open the file in a text editor, find
the placeholder ID below, and replace it with your real YouTube video ID
(the part of the URL after `watch?v=` — e.g. for
`https://www.youtube.com/watch?v=dQw4w9WgXcQ` the ID is `dQw4w9WgXcQ`).

| File               | Find this placeholder            | Replace with |
|--------------------|-----------------------------------|--------------|
| `index.html`       | `VIDEO_ID_TEAM`                   | your team introduction video's YouTube ID |
| `challenge-1.html` | `VIDEO_ID_CHALLENGE_1`            | Introduction video ID |
| `challenge-2.html` | `VIDEO_ID_CHALLENGE_2`            | Discover Africa video ID |
| `challenge-3.html` | `VIDEO_ID_CHALLENGE_3`            | Help-Lub video ID |
| `challenge-4.html` | `VIDEO_ID_CHALLENGE_4`            | Haunt For Treasure video ID |
| `challenge-5.html` | `VIDEO_ID_CHALLENGE_5`            | Launch Your Mission video ID |

Each placeholder appears inside a line like this:

```html
<iframe src="https://www.youtube.com/embed/VIDEO_ID_TEAM" ...>
```

Just swap the ID inside `/embed/...` — nothing else needs to change. The
embed is fully responsive and needs no JavaScript.

## 2. Replace the photos
Save your real photos into `assets/images/`, using these exact filenames
(overwrite the placeholder `.svg` files, or add `.jpg` versions and update
the `src` in the HTML — either works):

- `team-photo.jpg` — the whole group photo (home page)
- `member-1.jpg` … `member-5.jpg` — one portrait per teammate
- `challenge-1-hero.jpg` … `challenge-5-hero.jpg` — one photo per challenge page
- `cow-1.jpg`, `cow-2.jpg`, `cow-3.jpg` — cattle photos on Challenge 5 (Launch Your Mission)

## 3. Fill in the real content
Open each HTML file in a text editor and replace the placeholder text:

- `index.html` — team member names, roles, and short bios
- `challenge-4.html` — Haunt For Treasure still needs its real story (brief,
  approach, and what the team learned)

Everything is plain HTML — search for the word you want to change and type
over it.

## 4. Preview the site
Open `index.html` directly in a browser, or serve the folder locally:

```
python3 -m http.server 8000
```

then visit `http://localhost:8000`.

